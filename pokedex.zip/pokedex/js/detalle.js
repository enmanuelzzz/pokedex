const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const pokemonId = urlParams.get("id");

if (pokemonId) {
    fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonId}`)
        .then((response) => response.json())
        .then((data) => mostrarDetallesPokemon(data))
        .catch((error) => console.error("Error al obtener el Pokémon:", error));
}

function mostrarDetallesPokemon(pokemon) {
    document.querySelector("#pokemon-nombre").textContent = pokemon.name;
    document.querySelector("#pokemon-imagen").src = pokemon.sprites.other["official-artwork"].front_default;
    // Agrega aquí más detalles, como estadísticas o movimientos.
}
